---
name: Documentation improvement
about: Suggest an improvement on the Documentation
title: 'doc: '
labels: kind:documentation
assignees: ''

---

Please explain what do you suggest on the Documentation, what you would see instead.
