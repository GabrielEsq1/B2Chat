---
name: Module/Intent request
about: Suggest an intent or a module for Olivia
title: 'intent/module: create a ... module/intent'
labels: kind:module-enhancement
assignees: ''

---

**Describe what the module or intent should do** and **if this should be a module or an intent**
Please specify if you will implement this module or not.
